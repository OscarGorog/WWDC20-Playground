import Foundation

public protocol InformationViewDelegate {
    func helpButtonWasPressed()
}
