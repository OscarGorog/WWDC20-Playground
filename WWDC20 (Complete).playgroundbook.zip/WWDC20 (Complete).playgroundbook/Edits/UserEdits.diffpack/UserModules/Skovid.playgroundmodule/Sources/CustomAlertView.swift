
import UIKit

/// A custom alert view that can contain an array of `CustomAlertAction`
public class CustomAlertView: UIView {
    private var alertActions: [CustomAlertAction]!
    private var titleLabelText: String!
    private var titleLabelFontSize: CGFloat!
    lazy private var titleLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.text = titleLabelText
        label.textAlignment = .center
        label.numberOfLines = 0
        label.font = .systemFont(ofSize: titleLabelFontSize, weight: .semibold)
        return label
    }()
    lazy private var stackView: UIStackView = {
        let stackView = UIStackView()
        stackView.translatesAutoresizingMaskIntoConstraints = false
        stackView.axis = .vertical
        stackView.addArrangedSubview(titleLabel)
        let spacerView = UIView()
        spacerView.heightAnchor.constraint(equalToConstant: 12).isActive = true
        stackView.addArrangedSubview(spacerView)
        return stackView
    }()
    
    public init(frame: CGRect, titleText: String, titleLabelFontSize: CGFloat = 30) {
        super.init(frame: frame)
        self.alertActions = []
        self.titleLabelText = titleText
        self.titleLabelFontSize = titleLabelFontSize
        setupView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setupView()
    }
    
    public func addAction(_ action: CustomAlertAction) {
        self.alertActions.append(action)
        self.stackView.addArrangedSubview(createButton(with: action.buttonText))
    }
    
    private func setupView() {
        self.translatesAutoresizingMaskIntoConstraints = false
        self.backgroundColor = .systemGroupedBackground
        self.layer.cornerRadius = 16
        
        self.addSubview(stackView)
        setConstraints()
    }
    
    private func createButton(with text: String) -> UIButton {
        let button = UIButton()
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitle(text, for: .normal)
        button.titleLabel?.font = .systemFont(ofSize: 20, weight: .regular)
        button.setTitleColor(.systemBlue, for: .normal)
        button.addTarget(self, action: #selector(runCompletionHandler), for: .touchUpInside)
        button.heightAnchor.constraint(equalToConstant: 32).isActive = true
        return button
    }
    
    private func setConstraints() {
        // stackView
        NSLayoutConstraint.activate([
            self.centerXAnchor.constraint(equalTo: stackView.centerXAnchor),
            self.centerYAnchor.constraint(equalTo: stackView.centerYAnchor),
            self.leadingAnchor.constraint(equalTo: stackView.leadingAnchor, constant: -30),
            self.trailingAnchor.constraint(equalTo: stackView.trailingAnchor, constant: 30),
        ])
    }
    
    @objc func runCompletionHandler(sender: UIButton) {
        if let action = self.alertActions.first(where: { $0.buttonText == sender.title(for: .normal) }) {
            action.completionHandler()
        }
    }
}

