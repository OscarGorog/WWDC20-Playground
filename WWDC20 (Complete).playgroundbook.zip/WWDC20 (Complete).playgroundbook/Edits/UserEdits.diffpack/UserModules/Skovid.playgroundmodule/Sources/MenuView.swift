import UIKit
import Foundation

/// A subclass of  `CustomAlertView` that is pre-set up to present the menu  view
public class MenuView: CustomAlertView {
    private var gameScene: GameScene!
    
    public init(gameScene: GameScene) {
        super.init(frame: .zero, titleText: "Main Menu", titleLabelFontSize: 30)
        self.gameScene = gameScene
        
        addActions()
    }
    
    private func addActions() {
        self.addAction(CustomAlertAction(buttonText: "Play") {
            UIView.animate(withDuration: 0.75, delay: 0, options: .curveEaseOut, animations: {
                self.alpha = 0
            }, completion: { (_) in
                self.removeFromSuperview()
                self.gameScene.startGame()
            })
        })
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

