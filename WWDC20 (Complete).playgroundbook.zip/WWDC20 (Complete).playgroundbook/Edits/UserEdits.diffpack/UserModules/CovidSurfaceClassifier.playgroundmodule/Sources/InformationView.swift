import UIKit

public class InformationView: UIView {
    lazy private var informationLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.text = ""
        label.textAlignment = .left
        label.font = .systemFont(ofSize: 20, weight: .semibold)
        return label
    }()
    lazy private var helpButton: UIButton = {
        let button = UIButton()
        button.translatesAutoresizingMaskIntoConstraints = false
        button.titleLabel?.font = .systemFont(ofSize: 20, weight: .semibold)
        button.setImage(UIImage(systemName: "questionmark.circle", withConfiguration: UIImage.SymbolConfiguration(font: UIFont.systemFont(ofSize: 20, weight: .medium))), for: .normal)
        button.tintColor = .black
        button.addTarget(self, action: #selector(helpButtonWasPressed), for: .touchUpInside)
        return button
    }()
    lazy private var stackView: UIStackView = {
        let stackView = UIStackView()
        stackView.translatesAutoresizingMaskIntoConstraints = false
        stackView.distribution = .fillProportionally
        stackView.axis = .horizontal
        stackView.addArrangedSubview(informationLabel)
        stackView.addArrangedSubview(helpButton)
        return stackView
    }()
    public var delegate: InformationViewDelegate!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setupView()
    }
    
    private func setupView() {
        self.translatesAutoresizingMaskIntoConstraints = false
        self.backgroundColor = UIColor.systemGroupedBackground.withAlphaComponent(0.7)
        self.layer.cornerRadius = 16
        
        self.addSubview(stackView)
        setConstraints()
    }
    
    private func setConstraints() {
        // scoreLabel
        NSLayoutConstraint.activate([
            self.topAnchor.constraint(equalTo: stackView.topAnchor, constant: -12), //fix
            self.leadingAnchor.constraint(equalTo: stackView.leadingAnchor, constant: -20), //fix
            self.bottomAnchor.constraint(equalTo: stackView.bottomAnchor, constant: 12),
            self.trailingAnchor.constraint(equalTo: stackView.trailingAnchor, constant: 20)
        ])
    }
    
    public func setSessionState(_ arSessionState: ARSessionState) {
        informationLabel.text = arSessionState.description
    }
    
    @objc private func helpButtonWasPressed() {
        delegate.helpButtonWasPressed()
    }
}
