import Foundation

/// Shows which direction a player/computer is moving in
public enum MovingDirection: String {
    case straight = "Straight"
    case left = "Left"
    case right = "Right"
}
