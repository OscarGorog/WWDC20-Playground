import SpriteKit

/// A `SharedSpriteNode` subclass that creates a  `Player` node
public class Player: SharedSpriteNode {
    public var isInvincible: Bool = true
    
    init(texture: SKTexture) {
        super.init(texture: texture, color: .clear, size: texture.size())
        setupNode()
    }
    
    private func setupNode() {
        alpha = 0
        isInfected = false
        movingDirection = .straight
        
        setupPhysicsBody()
    }
    
    private func setupPhysicsBody() {
        guard let texture = self.texture else { return }
        physicsBody = SKPhysicsBody(texture: texture, size: texture.size())
        physicsBody?.isDynamic = true
        physicsBody?.categoryBitMask = Bitmasks.notInfected
        physicsBody?.contactTestBitMask = Bitmasks.infected
        physicsBody?.collisionBitMask = 0
        physicsBody?.usesPreciseCollisionDetection = true
        
        createPlayerChild()
    }
    
    private func createPlayerChild() {
        guard let texture = self.texture else { return }
        let playerNode = SKShapeNode(rectOf: texture.size())
        playerNode.physicsBody = SKPhysicsBody(texture: texture, size: texture.size())
        playerNode.physicsBody?.isDynamic = true
        playerNode.physicsBody?.categoryBitMask = Bitmasks.player
        playerNode.physicsBody?.contactTestBitMask = Bitmasks.tree
        playerNode.physicsBody?.collisionBitMask = 0
        playerNode.physicsBody?.usesPreciseCollisionDetection = true
        self.addChild(playerNode)
    }
    
    required init(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

