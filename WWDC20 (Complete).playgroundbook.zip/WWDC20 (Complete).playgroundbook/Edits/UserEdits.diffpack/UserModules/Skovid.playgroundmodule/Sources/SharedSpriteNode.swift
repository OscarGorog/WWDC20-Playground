import SpriteKit
import Foundation

/// A `SKSpriteNode` subclass that creates a link between `Player` and `Computer` and shares default variables
public class SharedSpriteNode: SKSpriteNode {
    public var isInfected: Bool!
    public var movingDirection: MovingDirection!
}
