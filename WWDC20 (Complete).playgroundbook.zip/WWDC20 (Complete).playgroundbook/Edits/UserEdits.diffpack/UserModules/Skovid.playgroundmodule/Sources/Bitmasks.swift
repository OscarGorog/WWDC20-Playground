
import Foundation

/// Manages all the bitmasks of the game
public struct Bitmasks {
    static let player: UInt32 = 0x1 << 0
    static let notInfected: UInt32 = 0x1 << 1
    static let infected: UInt32 = 0x1 << 2
    static let computerLeftBorder: UInt32 = 0x1 << 3
    static let computerRightBorder: UInt32 = 0x1 << 4
    static let computerLeftBottomBorder: UInt32 = 0x1 << 5
    static let computerRightBottomBorder: UInt32 = 0x1 << 6
    static let tree: UInt32 = 0x1 << 6
}
