/// A helper class used to work out how many days Covid-19 can last on a surface
public enum Surface: String, CustomStringConvertible {
    case skin
    case cardboard
    case paper
    case fabric
    case plastic
    case marble
    case wood
    case glass
    case stainlessSteel = "stainless steel"
    
    public var description: String {
        switch self {
        case .skin:
            return "Up to 2 days, but it cannot infect you unless you touch your mouth, nose or a cut"
        case .cardboard, .paper, .fabric:
            return "1 day"
        case .plastic, .marble:
            return "3 days"
        case .wood:
            return "4 days"
        case .glass:
            return "5 days"
        case .stainlessSteel:
            return "Up to 7 days"
        }
    }
}
