import UIKit
import SpriteKit
import GameplayKit

/// The underlying view controller of `GameScene`
public class SkovidGameViewController: UIViewController {
    
    // MARK: - Variables
    private var skView: SKView!
    private var menuView: MenuView!
    public var gameScene: GameScene!
    
    // MARK: - Functions
    public override func viewDidLoad() {
        super.viewDidLoad()
        setupView()
    }
    
    /// Sets up the view
    private func setupView() {
        // Create the SKView
        skView = SKView()
        skView.ignoresSiblingOrder = true
        
        skView.translatesAutoresizingMaskIntoConstraints = false
        self.view.addSubview(skView)
        
        // Create the GameScene
        gameScene = GameScene(size: view.bounds.size)
        gameScene.skovidGameViewController = self
        skView.presentScene(gameScene)
        
        // Create the MenuView
        menuView = MenuView(gameScene: gameScene)
        self.view.addSubview(menuView)
        
        setConstraints()
    }
    
    /// Sets the constraints for the view
    private func setConstraints() {
        // skView
        NSLayoutConstraint.activate([
            view.topAnchor.constraint(equalTo: skView.topAnchor),
            view.leftAnchor.constraint(equalTo: skView.leftAnchor),
            view.bottomAnchor.constraint(equalTo: skView.bottomAnchor),
            view.rightAnchor.constraint(equalTo: skView.rightAnchor)
        ])
        
        // menuView
        NSLayoutConstraint.activate([
            menuView.centerXAnchor.constraint(equalTo: view.centerXAnchor, constant: 0),
            menuView.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: 0),
            menuView.heightAnchor.constraint(equalToConstant: 175),
            menuView.widthAnchor.constraint(equalToConstant: 300)
        ])
    }
}

