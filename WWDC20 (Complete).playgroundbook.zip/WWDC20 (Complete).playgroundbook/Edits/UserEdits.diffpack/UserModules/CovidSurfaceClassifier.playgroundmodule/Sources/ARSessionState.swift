import Foundation

/// A helper class used to display a message to the user while running the playground
public enum ARSessionState: CustomStringConvertible {
    case ready
    case temporarilyUnavailable
    case failed
    
    public var description: String {
        switch self {
        case .ready:
            return "Tap on any surface to find out how long Covid-19 can survive on it for!"
        case .temporarilyUnavailable:
            return "Were just making some adjustments, please wait a second"
        case .failed:
            return "Something went wrong, please try restarting the playground"
        }
    }
}
