import UIKit
import Foundation

/// A custom view that shows the score of the player
public class ScoreView: UIView {
    lazy private var scoreLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.text = "Not Infected"
        label.textColor = .systemGreen
        label.textAlignment = .center
        label.font = .systemFont(ofSize: 20, weight: .semibold)
        return label
    }()
    public var peopleInfected: Int = -1 {
        didSet {
            if peopleInfected >= 0 {
                scoreLabel.textColor = .systemRed
                scoreLabel.text = "Infected: \(peopleInfected) people"
            }
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setupView()
    }
    
    private func setupView() {
        self.translatesAutoresizingMaskIntoConstraints = false
        self.backgroundColor = .systemGroupedBackground
        self.layer.cornerRadius = 16
        
        self.addSubview(scoreLabel)
        
        setConstraints()
    }
    
    private func setConstraints() {
        // scoreLabel
        NSLayoutConstraint.activate([
            self.topAnchor.constraint(equalTo: scoreLabel.topAnchor, constant: -12), //fix
            self.leadingAnchor.constraint(equalTo: scoreLabel.leadingAnchor, constant: -12), //fix
            self.bottomAnchor.constraint(equalTo: scoreLabel.bottomAnchor, constant: 12),
            self.trailingAnchor.constraint(equalTo: scoreLabel.trailingAnchor, constant: 12)
        ])
    }
    
    public func getScoreDescription() -> String {
        var message = ""
        if peopleInfected > 10 {
            message = "Good work! You successfully delivered the dub dub merch but infected quite a few people (\(peopleInfected)). Try to infect less next time!"
        } else if peopleInfected >= 5 {
            message = "Good work! You successfully delivered the dub dub merch but infetced a few people (\(peopleInfected)). Try to infect less next time!"
        } else if peopleInfected >= 3 {
            message = "Well done! You successfully delivered the dub dub merch and only infected a few people (\(peopleInfected))!"
        } else if peopleInfected >= 1 {
            message = "Well done! You successfully delivered the dub dub merch while infecting very few people (\(peopleInfected))!"
        } else if peopleInfected == 0 {
            message = "Well done! You were infected while delivering the package but still successfully delivered the dub dub merch!"
        } else if peopleInfected == -1 {
            message = "Excellent work! You successfully delivered the dub dub merch without infecting anyone!"
        }
        return message.appending("\nThank you for playing my game and please stay safe!")
    }
}

