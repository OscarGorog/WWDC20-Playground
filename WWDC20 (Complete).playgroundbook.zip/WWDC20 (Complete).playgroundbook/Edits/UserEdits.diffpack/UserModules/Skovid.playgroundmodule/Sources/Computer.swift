import SpriteKit

/// A `SharedSpriteNode` subclass that creates a `Computer` node
public class Computer: SharedSpriteNode {
    init(texture: SKTexture) {
        super.init(texture: texture, color: .clear, size: texture.size())
        setupNode()
    }
    
    private func setupNode() {
        name = "computer"
        isInfected = Bool.random()
        movingDirection = .straight
        
        setupPhysicsBody()
    }
    
    private func setupPhysicsBody() {
        self.texture = isInfected ? SKTexture(imageNamed: "Skiier-Straight-Positive") : SKTexture(imageNamed: "Skiier-Straight-Negative") //fix
        guard let texture = self.texture else { return }
        physicsBody = SKPhysicsBody(texture: texture, size: texture.size())
        physicsBody?.isDynamic = true
        physicsBody?.categoryBitMask = isInfected ? Bitmasks.infected : Bitmasks.notInfected
        physicsBody?.collisionBitMask = 0
        physicsBody?.usesPreciseCollisionDetection = true
        
        setupBorderNodes()
    }
    
    private func setupBorderNodes() {
        // Create the left side of the computer auto move
        let leftContactNode = SKShapeNode(rectOf: self.size)
        leftContactNode.name = "leftContactNode"
        
        leftContactNode.physicsBody = SKPhysicsBody(rectangleOf: self.size)
        leftContactNode.physicsBody?.isDynamic = true
        leftContactNode.physicsBody?.categoryBitMask = Bitmasks.computerLeftBorder
        leftContactNode.physicsBody?.contactTestBitMask = Bitmasks.tree
        leftContactNode.physicsBody?.collisionBitMask = 0
        leftContactNode.physicsBody?.usesPreciseCollisionDetection = true
        leftContactNode.position = CGPoint(x: leftContactNode.position.x - (self.size.width / 2), y: leftContactNode.position.y - 5)
        
        self.addChild(leftContactNode)
        
        // Create the right side of the computer auto move
        let rightContactNode = SKShapeNode(rectOf: self.size)
        rightContactNode.name = "rightContactNode"
        
        rightContactNode.physicsBody = SKPhysicsBody(rectangleOf: self.size)
        rightContactNode.physicsBody?.isDynamic = true
        rightContactNode.physicsBody?.categoryBitMask = Bitmasks.computerRightBorder
        rightContactNode.physicsBody?.contactTestBitMask = Bitmasks.tree
        rightContactNode.physicsBody?.collisionBitMask = 0
        rightContactNode.physicsBody?.usesPreciseCollisionDetection = true
        rightContactNode.position = CGPoint(x: rightContactNode.position.x + (self.size.width / 2), y: rightContactNode.position.y - 5)
        
        self.addChild(rightContactNode)
        
        // Create the left bottom side of the computer auto move
        let leftBottomContactNode = SKShapeNode(rectOf: self.size)
        leftBottomContactNode.name = "leftBottomContactNode"
        
        leftBottomContactNode.physicsBody = SKPhysicsBody(rectangleOf: CGSize(width: 30, height: 20))
        leftBottomContactNode.physicsBody?.isDynamic = true
        leftBottomContactNode.physicsBody?.categoryBitMask = Bitmasks.computerLeftBottomBorder
        leftBottomContactNode.physicsBody?.contactTestBitMask = Bitmasks.tree
        leftBottomContactNode.physicsBody?.collisionBitMask = 0
        leftBottomContactNode.physicsBody?.usesPreciseCollisionDetection = true
        leftBottomContactNode.position = CGPoint(x: ((leftBottomContactNode.position.x / 2) / (self.size.width / 2)) - 15, y: leftBottomContactNode.position.y - 80)
        
        self.addChild(leftBottomContactNode)
        
        // Create the right bottom side of the computer auto move
        let rightBottomContactNode = SKShapeNode(rectOf: self.size)
        rightBottomContactNode.name = "rightBottomContactNode"
        
        rightBottomContactNode.physicsBody = SKPhysicsBody(rectangleOf: CGSize(width: 30, height: 20))
        rightBottomContactNode.physicsBody?.isDynamic = true
        rightBottomContactNode.physicsBody?.categoryBitMask = Bitmasks.computerLeftBottomBorder
        rightBottomContactNode.physicsBody?.contactTestBitMask = Bitmasks.tree
        rightBottomContactNode.physicsBody?.collisionBitMask = 0
        rightBottomContactNode.physicsBody?.usesPreciseCollisionDetection = true
        rightBottomContactNode.position = CGPoint(x: ((rightBottomContactNode.position.x / 2) / (self.size.width / 2)) + 15, y: rightBottomContactNode.position.y - 80)
        
        self.addChild(rightBottomContactNode)
    }
    
    required init(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
