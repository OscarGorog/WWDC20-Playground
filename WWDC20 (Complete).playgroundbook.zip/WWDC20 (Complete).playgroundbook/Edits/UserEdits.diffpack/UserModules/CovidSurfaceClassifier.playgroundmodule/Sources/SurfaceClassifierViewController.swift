import UIKit
import ARKit
import Vision

/// Manages the AR scene view and classifying the surfaces
public class SurfaceClassifierViewController: UIViewController, InformationViewDelegate {
    
    // MARK: - Variables
    private var arSceneView: ARSCNView!
    private var informationView: InformationView!
    private var arSessionState: ARSessionState! {
        didSet {
            informationView.setSessionState(arSessionState)
        }
    }
    private var visionRequests: [VNRequest]!
    private var mlDispatchQueue: DispatchQueue!
    private var latestPrediction: String!
    
    // MARK: - Functions
    public override func viewDidLoad() {
        super.viewDidLoad()
        setupView()
    }
    
    public override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        setUpSceneView()
    }
    
    /// Sets up the scene view
    private func setUpSceneView() {
        let configuration = ARWorldTrackingConfiguration()
        configuration.planeDetection = .vertical
        
        arSceneView.session.run(configuration)
        arSceneView.delegate = self
    }
    
    /// Sets up the view
    private func setupView() {
        // Create the ARSCNView
        arSceneView = ARSCNView()
        arSceneView.translatesAutoresizingMaskIntoConstraints = false
        arSceneView.autoenablesDefaultLighting = true
        view.addSubview(arSceneView)
        
        // Create the InformationView
        informationView = InformationView()
        informationView.delegate = self
        informationView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(informationView)
        
        // Add constraints to the view
        setConstraints()
        
        // Create the SCNScene
        let scene = SCNScene()
        arSessionState = .temporarilyUnavailable
        arSceneView.scene = scene
        
        // Create the tap gesture
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleTap(recognizer:)))
        view.addGestureRecognizer(tapGesture)
        
        // Setup the classifier
        do {
            let url = try MLModel.compileModel(at: #fileLiteral(resourceName: "SurfaceClassifier 2.mlmodel"))
            let mlModel = try MLModel(contentsOf: url)
            let model = try VNCoreMLModel(for: mlModel)
            
            let classificationRequest = VNCoreMLRequest(model: model, completionHandler: classificationCompletionHandler)
            classificationRequest.imageCropAndScaleOption = .scaleFit
            visionRequests = [classificationRequest]
            
            mlDispatchQueue = DispatchQueue(label: "com.SurfaceClassifier.MLDispatchQueue")
            loopCoreMLUpdate()
        } catch {
            arSessionState = .failed
        }
    }
    
    /// Sets the view's constraints
    private func setConstraints() {
        // arSceneView
        NSLayoutConstraint.activate([
            arSceneView.topAnchor.constraint(equalTo: view.topAnchor),
            arSceneView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            arSceneView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            arSceneView.trailingAnchor.constraint(equalTo: view.trailingAnchor)
        ])
        
        // informationView
        NSLayoutConstraint.activate([
            informationView.topAnchor.constraint(equalTo: view.topAnchor, constant: 75),
            informationView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 100),
            informationView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -100),
            informationView.heightAnchor.constraint(equalToConstant: 60)
        ])
    }
    
    // MARK: - Interaction
    
    /// Handle a tap when the user presses the screen
    @objc func handleTap(recognizer: UIGestureRecognizer) {
        // Make sure the view is ready
        if arSessionState == .ready {
            let tapLocation = recognizer.location(in: arSceneView)
            let hitTestResults = arSceneView.hitTest(tapLocation, types: .featurePoint)
            
            guard let hitTestResult = hitTestResults.first else { return }
            let translation = hitTestResult.worldTransform.columns.3
            
            // Create a text node from the hit point
            createTextFromPosition(SCNVector3(translation.x, translation.y, translation.z))
        }
    }
    
    /// Creates and adds a text node with the corresponding surface and lifetime of COVID-19
    func createTextFromPosition(_ position: SCNVector3) {
        // Create a multiline string
        let attributedString = NSMutableAttributedString(string: latestPrediction, attributes: [.font: UIFont.systemFont(ofSize: 4, weight: .semibold)])
        attributedString.append(NSMutableAttributedString(string: "\nCovid-19 Lifetime: \(Surface(rawValue: latestPrediction.lowercased()) ?? .cardboard)", attributes: [.font: UIFont.systemFont(ofSize: 2, weight: .semibold)]))
        
        // Create the text geometry
        let textGeometry = SCNText()
        textGeometry.string = attributedString
        textGeometry.flatness = 0
        textGeometry.firstMaterial?.diffuse.contents = UIColor.white
        
        // Create a text node and apply the textGeometry
        let textNode = SCNNode()
        textNode.geometry = textGeometry
        textNode.scale = SCNVector3(0.005, 0.005, 0.005)
        textNode.position = position
        textNode.name = "textNode"
        centerPivot(for: textNode)
        
        // Make the text follow the camera
        let lookAtCameraConstraint = SCNBillboardConstraint()
        lookAtCameraConstraint.freeAxes = [.Y, .X]
        textNode.constraints = [lookAtCameraConstraint]
        
        // See if the new textNode is close to any of the other textNodes and if so, update the position and text instead of creating a new node
        var doesOverlap = false
        for child in arSceneView.scene.rootNode.childNodes where child.name == "textNode" {
            if child.position.overlaps(textNode.position) && !doesOverlap {
                doesOverlap = true
                child.position = textNode.position
                (child.geometry as! SCNText).string = attributedString
            }
        }
        
        if !doesOverlap {
            // Add the text to the view
            arSceneView.scene.rootNode.addChildNode(textNode)
        }
    }
    
    /// Changes the pivot of a `SCNNode`
    func centerPivot(for node: SCNNode) {
        let (min, max) = node.boundingBox
        node.pivot = SCNMatrix4MakeTranslation(
            min.x + (max.x - min.x) / 2,
            min.y + (max.y - min.y) / 2,
            min.z + (max.z - min.z) / 2
        )
    }
    
    // MARK: - CoreML Vision Handling
    
    /// Creates a loop for classifying the surface
    func loopCoreMLUpdate() {
        mlDispatchQueue.async {
            self.updateCoreML()
            self.loopCoreMLUpdate()
        }
    }
    
    /// The completion handler for the classifier
    func classificationCompletionHandler(request: VNRequest, error: Error?) {
        if error != nil {
            print(error!)
        } else {
            if let result = request.results?.first as? VNClassificationObservation {
                DispatchQueue.main.async {
                    self.arSessionState = .ready
                    self.latestPrediction = result.identifier
                }
            }
        }
    }
    
    /// Classifies what is on the screen at the current frame
    func updateCoreML() {
        // Get the captured image as a CVPixelBuffer
        let pixelBuffer = arSceneView.session.currentFrame?.capturedImage
        if let pixelBuffer = pixelBuffer {
            // Convert the pixelBuffer to a CIImage
            let ciImage = CIImage(cvPixelBuffer: pixelBuffer)
            
            let imageRequestHandler = VNImageRequestHandler(ciImage: ciImage)
            do {
                // Perform the request
                try imageRequestHandler.perform(self.visionRequests)
            } catch {
                print(error)
            }
        }
    }
    
    /// Triggered when the help button is pressed
    public func helpButtonWasPressed() {
        let helpAlert = UIAlertController(title: "Help", message: "If the playground is not detecting the right surface type, try holding the camera closer to the surface and try to not have any other surfaces in view", preferredStyle: .alert)
        helpAlert.addAction(UIAlertAction(title: "OK", style: .cancel, handler: nil))
        
        self.present(helpAlert, animated: true, completion: nil)
    }
}

extension SurfaceClassifierViewController: ARSCNViewDelegate {
    // MARK: - Session Tracking
    public func sessionWasInterrupted(_ session: ARSession) {
        arSessionState = .temporarilyUnavailable
    }
    
    public func sessionInterruptionEnded(_ session: ARSession) {
        arSessionState = .ready
    }
    
    public func session(_ session: ARSession, didFailWithError error: Error) {
        arSessionState = .failed
    }
}
