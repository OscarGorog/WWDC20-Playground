import Foundation

/// A custom alert action that can be added to a `CustomAlertView`
public class CustomAlertAction {
    public var buttonText: String!
    public var completionHandler: () -> Void?
    
    public init(buttonText: String, completionHandler: @escaping () -> Void) {
        self.buttonText = buttonText
        self.completionHandler = completionHandler
    }
}
