import ARKit

public extension SCNVector3 {
    func overlaps(_ vector: SCNVector3) -> Bool {
        let xRange = x...x + 0.5
        let yRange = y...y + 0.5
        let ZRange = z...z + 0.5
        
        let xVectorContains = xRange.contains(vector.x)
        let yVectorContains = yRange.contains(vector.y)
        let zVectorContains = ZRange.contains(vector.z)
        
        return xVectorContains || yVectorContains || zVectorContains
    }
}
