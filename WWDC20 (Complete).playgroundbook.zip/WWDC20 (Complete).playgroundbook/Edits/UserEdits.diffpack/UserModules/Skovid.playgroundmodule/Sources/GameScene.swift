import SpriteKit

/// Manages the game
public class GameScene: SKScene, SKPhysicsContactDelegate {
    
    // MARK: - Variables
    public var skovidGameViewController: SkovidGameViewController!
    private var scoreView: ScoreView!
    private var treeTimer: Timer!
    private var computerTimer: Timer!
    private var player: Player?
    private var postbox: SKSpriteNode?
    private var gameHasEnded: Bool!
    
    // MARK: - Functions
    public override func didMove(to view: SKView) {
        setupScene()
    }
    
    /// Sets up the view
    private func setupScene() {
        self.backgroundColor = .white
        self.physicsWorld.gravity = .zero
        self.physicsWorld.contactDelegate = self
        self.gameHasEnded = false
        
        treeTimer = Timer.scheduledTimer(timeInterval: 0.10, target: self, selector: #selector(createTree), userInfo: nil, repeats: true)
        computerTimer = Timer.scheduledTimer(timeInterval: 5, target: self, selector: #selector(createComputer), userInfo: nil, repeats: true)
    }
    
    /// Starts the game
    public func startGame() {
        // Create score view
        scoreView = ScoreView()
        scoreView.alpha = 0
        skovidGameViewController.view.addSubview(scoreView)
        
        // Add score view constraints
        NSLayoutConstraint.activate([
            skovidGameViewController.view.topAnchor.constraint(equalTo: scoreView.topAnchor, constant: -75),
            skovidGameViewController.view.leadingAnchor.constraint(equalTo: scoreView.leadingAnchor, constant: -20),
            scoreView.widthAnchor.constraint(equalToConstant: 200),
            scoreView.heightAnchor.constraint(equalToConstant: 50)
        ])
        
        // Create the player
        createPlayer()
    }
    
    /// Restarts the game, and by default creates the player too.
    public func restartGame(withPlayer: Bool = true) {
        // Fade out all nodes
        let fadeAction = SKAction.fadeOut(withDuration: 0.75)
        let removeAction = SKAction.removeFromParent()
        for child in self.children {
            child.run(SKAction.sequence([fadeAction, removeAction]))
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.75) {
            self.setupScene()
            if withPlayer {
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.75) {
                    self.startGame()
                }
            }
        }
    }
    
    /// Creates the effect of  invincibility for the player
    private func createInvincibility() {
        if let player = player {
            // Fade the player in
            let fadeInAction = SKAction.fadeIn(withDuration: 0.2)
            let showInvincibilityAction = SKAction.run {
                // Create the effect of invincibility
                let delayAction = SKAction.wait(forDuration: 0.2)
                let invincibleEffectAction = SKAction.colorize(with: UIColor.white.withAlphaComponent(0.5), colorBlendFactor: 1, duration: 0.2)
                let revertInvincibleEffectAction = SKAction.colorize(withColorBlendFactor: 0.0, duration: 0.2)
                let resetInvincibilityAction = SKAction.run { player.isInvincible = false }
                
                var invincibilityActions = [SKAction](repeating: [invincibleEffectAction, revertInvincibleEffectAction], count: 7) // 2.8 seconds of invincibility
                invincibilityActions.append(resetInvincibilityAction)
                invincibilityActions.insert(delayAction, at: 0)
                
                player.run(SKAction.sequence(invincibilityActions))
            }
            player.run(SKAction.sequence([fadeInAction, showInvincibilityAction]))
            
            UIView.animate(withDuration: 0.75, delay: 0, options: .curveEaseOut, animations: {
                self.scoreView.alpha = 1
            }, completion: nil)
            
            // Setup the game timer
            setupGameTimer()
        }
    }
    
    /// Sets up the game timer which controls when to show the postbox
    private func setupGameTimer() {
        let endGameTimer = SKAction.wait(forDuration: 40)
        let removeComputersAndTrees = SKAction.run {
            self.treeTimer.invalidate()
            self.computerTimer.invalidate()
            if let computers = self.children.filter({ $0.name == "computer" }) as? [SKSpriteNode] {
                computers.forEach { (computer) in
                    let fadeAction = SKAction.fadeOut(withDuration: 0.75)
                    let removeAction = SKAction.removeFromParent()
                    computer.run(SKAction.sequence([fadeAction, removeAction]))
                }
            }
        }
        let waitAction = SKAction.wait(forDuration: 3)
        let createPostbox = SKAction.run {
            self.createPostbox()
        }
        self.run(SKAction.sequence([endGameTimer, removeComputersAndTrees, waitAction, createPostbox]), withKey: "createPostboxTimer")
    }
    
    // MARK: - Creating Nodes
    
    /// Creates the player
    private func createPlayer() {
        // Create the player
        let texture = SKTexture(imageNamed: "Skiier-Straight-Negative")
        let player = Player(texture: texture)
        player.position = CGPoint(x: self.frame.size.width / 2, y: self.frame.size.height - player.size.height * 4)
        
        self.player = player
        self.addChild(player)
        
        // Create invincibility for the player
        createInvincibility()
    }
    
    /// Creates a tree at a random x position along the bottom of the view
    @objc private func createTree() {
        // Create the tree
        let texture = SKTexture(imageNamed: "Tree")
        let tree = Tree(texture: texture)
        
        // Generate a random x position
        let randomXPosition = CGFloat.random(in: .zero...(self.view?.scene?.size.width ?? .zero))
        tree.position = CGPoint(x: randomXPosition, y: -tree.size.height)
        
        self.addChild(tree)
        
        let actions = [
            SKAction.moveTo(y: self.frame.size.height + tree.size.height, duration: 3.5),
            SKAction.wait(forDuration: 0.3),
            SKAction.removeFromParent()
        ]
        
        tree.run(SKAction.sequence(actions))
    }
    
    /// Creates a computer at a random x position along the top of the view
    @objc private func createComputer() {
        // Create the computer
        let texture = SKTexture(imageNamed: "Skiier-Straight-Negative")
        let computer = Computer(texture: texture)
        
        // Generate a random x position
        let randomXPosition = CGFloat.random(in: .zero...(self.view?.scene?.size.width ?? .zero))
        computer.position = CGPoint(x: randomXPosition, y: self.frame.size.height + computer.size.height)
        
        self.addChild(computer)
    }
    
    /// Creates the postbox for the player to deliver their dub dub merch
    private func createPostbox() {
        // Create the postbox
        let texture = SKTexture(imageNamed: "Postbox")
        postbox = SKSpriteNode(texture: texture)
        postbox!.position = CGPoint(x: self.frame.size.width / 2, y: -postbox!.size.height)
        self.addChild(postbox!)
        
        // Move the postbox up
        let moveUpAction = SKAction.moveTo(y: self.frame.size.height / 3, duration: 2)
        let movePlayerToPostboxAction = SKAction.run {
            if let player = self.player, let postbox = self.postbox {
                // End the game and disbale any user intreaction
                self.gameHasEnded = true
                player.removeAction(forKey: "movePlayer")
                if player.action(forKey: "spinAndMovePlayer") == nil {
                    self.player?.removeAction(forKey: "movePlayer")
                    let resetTextureAction = SKAction.setTexture(player.isInfected ? SKTexture(imageNamed: "Skiier-Straight-Positive") : SKTexture(imageNamed: "Skiier-Straight-Negative")) //fix
                    let presentWinAlert = SKAction.run { self.presentWinAlert() }
                    
                    // Move the player next to the postbox depending on where the player is
                    if player.position.x > self.frame.size.width / 2 {
                        if player.position.x > (self.frame.size.width / 2 + player.size.width + player.size.width / 2) {
                            player.texture = player.isInfected ? SKTexture(imageNamed: "Skiier-Left-Positive") : SKTexture(imageNamed: "Skiier-Left-Negative")
                        }
                        let moveToPostboxAction = SKAction.move(to: CGPoint(x: postbox.position.x + player.size.width + player.size.width / 2, y: postbox.position.y), duration: 1.5)
                        player.run(SKAction.sequence([moveToPostboxAction, resetTextureAction, presentWinAlert]))
                    } else {
                        if player.position.x < (self.frame.size.width / 2 - player.size.width - player.size.width / 2) {
                            player.texture = player.isInfected ? SKTexture(imageNamed: "Skiier-Right-Positive") : SKTexture(imageNamed: "Skiier-Right-Negative")
                        }
                        let moveToPostboxAction = SKAction.move(to: CGPoint(x: postbox.position.x - player.size.width - player.size.width / 2, y: postbox.position.y), duration: 1.5)
                        player.run(SKAction.sequence([moveToPostboxAction, resetTextureAction, presentWinAlert]))
                    }
                }
            }
        }
        postbox!.run(SKAction.sequence([moveUpAction, movePlayerToPostboxAction]), withKey: "createPostbox")
    }
    
    
    
    // MARK: - Game State Functions
    
    /// Creates a win alert once reaching the postbox
    private func presentWinAlert() {
        // Create the alert
        let winAlert = WinAlert(titleText: scoreView.getScoreDescription(), titleLabelFontSize: 20, skovidGameViewController: self.skovidGameViewController, gameScene: self)
        
        // Add the alert to the view
        self.skovidGameViewController.view.addSubview(winAlert)
        
        // winView constraints
        NSLayoutConstraint.activate([
            winAlert.centerXAnchor.constraint(equalTo: skovidGameViewController.view.centerXAnchor, constant: 0),
            winAlert.centerYAnchor.constraint(equalTo: skovidGameViewController.view.centerYAnchor, constant: 0),
            winAlert.heightAnchor.constraint(equalToConstant: 175),
            winAlert.widthAnchor.constraint(equalToConstant: self.frame.size.width - 400)
        ])
        
        UIView.animate(withDuration: 0.75, delay: 0, options: .curveEaseOut, animations: {
            winAlert.alpha = 1
            self.scoreView.alpha = 0
        }, completion: { (_) in
            self.scoreView.removeFromSuperview()
        })
    }
    
    /// End's the game
    private func endGameWith(_ node: Player) {
        // Stop spawning the trees and computers
        treeTimer.invalidate()
        computerTimer.invalidate()
        
        // Disable user interaction
        gameHasEnded = true
        
        // Remove all actions from all the nodes except for the player
        if let computersAndTrees = self.children.filter({ $0.name == "computer" || $0.name == "tree" }) as? [SKSpriteNode] {
            for node in computersAndTrees {
                node.physicsBody = nil
                node.removeAllChildren()
                node.removeAllActions()
            }
        }
        self.removeAction(forKey: "createPostboxTimer")
        self.removeAction(forKey: "createPostbox")
        if let postbox = postbox {
            postbox.removeAllActions()
            let fadeAction = SKAction.fadeOut(withDuration: 0.75)
            let removeAction = SKAction.removeFromParent()
            postbox.run(SKAction.sequence([fadeAction, removeAction]))
        }
        
        // Make the node spin off screen
        let spinAction = SKAction.rotate(byAngle: .pi * 2, duration: 1)
        node.run(SKAction.repeatForever(spinAction))
        if node.movingDirection == .straight {
            let moveAction = SKAction.moveTo(y: -node.size.height, duration: 3)
            let removeAction = SKAction.removeFromParent()
            node.run(SKAction.sequence([moveAction, removeAction]), withKey: "spinAndMovePlayer")
        } else if node.movingDirection == .left {
            let moveAction = SKAction.move(to: CGPoint(x: -node.size.width, y: -node.size.height), duration: 3)
            let removeAction = SKAction.removeFromParent()
            node.run(SKAction.sequence([moveAction, removeAction]), withKey: "spinAndMovePlayer")
        } else if node.movingDirection == .right {
            let moveAction = SKAction.move(to: CGPoint(x: self.view?.bounds.width ?? 0 + node.size.width, y: -node.size.height), duration: 3)
            let removeAction = SKAction.removeFromParent()
            node.run(SKAction.sequence([moveAction, removeAction]), withKey: "spinAndMovePlayer")
        }
        
        // Create the end game alert
        let endGameView = EndGameAlert(skovidGameViewController: self.skovidGameViewController, gameScene: self)
        
        // Add the alert to the view
        skovidGameViewController.view.addSubview(endGameView)
        
        // endGameView constraints
        NSLayoutConstraint.activate([
            endGameView.centerXAnchor.constraint(equalTo: skovidGameViewController.view.centerXAnchor, constant: 0),
            endGameView.centerYAnchor.constraint(equalTo: skovidGameViewController.view.centerYAnchor, constant: 0),
            endGameView.heightAnchor.constraint(equalToConstant: 175),
            endGameView.widthAnchor.constraint(equalToConstant: 300)
        ])
        
        UIView.animate(withDuration: 0.75, delay: 0, options: .curveEaseOut, animations: {
            endGameView.alpha = 1
            self.scoreView.alpha = 0
        }, completion: { (_) in
            self.scoreView.removeFromSuperview()
        })
    }
    
    // MARK: - Touches
    public override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if !gameHasEnded {
            if let player = player, let touch = touches.first {
                player.removeAction(forKey: "movePlayer")
                
                let location = touch.location(in: self.view)
                let touchSide = (location.x > self.frame.size.width / 2) ? "Right" : "Left"
                let moveAction = touchSide == "Right" ? SKAction.moveBy(x: 30, y: 0, duration: 0.1) : SKAction.moveBy(x: -30, y: 0, duration: 0.1)
                
                player.texture = SKTexture(imageNamed: player.isInfected ? "Skiier-\(touchSide)-Positive" : "Skiier-\(touchSide)-Negative")
                player.movingDirection = touchSide == "Right" ? .right : .left
                player.run(SKAction.repeatForever(moveAction), withKey: "movePlayer")
            }
        }
    }
    
    public override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        if !gameHasEnded {
            if let player = player {
                player.texture = SKTexture(imageNamed: player.isInfected ? "Skiier-Straight-Positive" : "Skiier-Straight-Negative")
                player.movingDirection = .straight
                player.removeAction(forKey: "movePlayer")
            }
        }
    }
    
    // MARK: - Contact
    public func didBegin(_ contact: SKPhysicsContact) {
        guard let nodeA = contact.bodyA.node else { return }
        guard let nodeB = contact.bodyB.node else { return }
        
        if (nodeA.physicsBody?.categoryBitMask == Bitmasks.computerLeftBottomBorder || nodeA.physicsBody?.categoryBitMask == Bitmasks.computerRightBottomBorder) && nodeB.physicsBody?.categoryBitMask == Bitmasks.tree {
            moveComputer(borderNode: nodeA as! SKShapeNode, computer: nodeA.parent as! Computer)
        } else if (nodeB.physicsBody?.categoryBitMask == Bitmasks.computerLeftBottomBorder || nodeB.physicsBody?.categoryBitMask == Bitmasks.computerRightBottomBorder) && nodeA.physicsBody?.categoryBitMask == Bitmasks.tree {
            moveComputer(borderNode: nodeB as! SKShapeNode, computer: nodeB.parent as! Computer)
        } else if (nodeA.physicsBody?.categoryBitMask == Bitmasks.computerLeftBorder || nodeA.physicsBody?.categoryBitMask == Bitmasks.computerRightBorder) && nodeB.physicsBody?.categoryBitMask == Bitmasks.tree {
            moveComputer(borderNode: nodeA as! SKShapeNode, computer: nodeA.parent as! Computer)
        } else if (nodeB.physicsBody?.categoryBitMask == Bitmasks.computerLeftBorder || nodeB.physicsBody?.categoryBitMask == Bitmasks.computerRightBorder) && nodeA.physicsBody?.categoryBitMask == Bitmasks.tree {
            moveComputer(borderNode: nodeB as! SKShapeNode, computer: nodeB.parent as! Computer)
        } else if nodeA.physicsBody?.categoryBitMask == Bitmasks.infected && nodeB.physicsBody?.categoryBitMask == Bitmasks.notInfected {
            if let nodeBPlayer = nodeB as? Player {
                if !nodeBPlayer.isInvincible {
                    infectNode(node: nodeB as! SharedSpriteNode)
                }
            } else {
                infectNode(node: nodeB as! SharedSpriteNode)
            }
        } else if nodeA.physicsBody?.categoryBitMask == Bitmasks.notInfected && nodeB.physicsBody?.categoryBitMask == Bitmasks.infected {
            if let nodeAPlayer = nodeA as? Player {
                if !nodeAPlayer.isInvincible {
                    infectNode(node: nodeA as! SharedSpriteNode)
                }
            } else {
                infectNode(node: nodeA as! SharedSpriteNode)
            }
        } else if nodeA.physicsBody?.categoryBitMask == Bitmasks.player && nodeB.physicsBody?.categoryBitMask == Bitmasks.tree && !(nodeA.parent as! Player).isInvincible {
            endGameWith(nodeA.parent as! Player)
        } else if nodeB.physicsBody?.categoryBitMask == Bitmasks.player && nodeA.physicsBody?.categoryBitMask == Bitmasks.tree && !(nodeB.parent as! Player).isInvincible {
            endGameWith(nodeB.parent as! Player)
        }
    }
    
    /// Moves a computer in either direction depending on its border node
    private func moveComputer(borderNode: SKShapeNode, computer: Computer) {
        let moveAction = borderNode.physicsBody?.categoryBitMask == Bitmasks.computerLeftBorder || borderNode.physicsBody?.categoryBitMask == Bitmasks.computerLeftBottomBorder ? SKAction.moveBy(x: 160, y: 0, duration: 1.0) : SKAction.moveBy(x: -160, y: 0, duration: 1.0)
        computer.movingDirection = borderNode.physicsBody?.categoryBitMask == Bitmasks.computerLeftBorder || borderNode.physicsBody?.categoryBitMask == Bitmasks.computerLeftBottomBorder ? .right : .left
        let resetTextureAction = SKAction.run {
            computer.movingDirection = .straight
            computer.texture = SKTexture(imageNamed: computer.isInfected ? "Skiier-Straight-Positive" : "Skiier-Straight-Negative")
        }
        let actions = SKAction.sequence([moveAction, resetTextureAction])
        if borderNode.physicsBody?.categoryBitMask == Bitmasks.computerLeftBorder || borderNode.physicsBody?.categoryBitMask == Bitmasks.computerLeftBottomBorder {
            computer.texture = SKTexture(imageNamed: computer.isInfected ? "Skiier-Right-Positive" : "Skiier-Right-Negative")
        } else {
            computer.texture = SKTexture(imageNamed: computer.isInfected ? "Skiier-Left-Positive" : "Skiier-Left-Negative")
        }
        
        computer.removeAction(forKey: "moveComputer")
        computer.run(actions, withKey: "moveComputer")
    }
    
    /// Infects a node (changes its color and bitmasks) and updates the score
    private func infectNode(node: SharedSpriteNode) {
        node.texture = SKTexture(imageNamed: "Skiier-\(node.movingDirection.rawValue)-Positive")
        node.isInfected = true
        node.physicsBody?.categoryBitMask = Bitmasks.infected
        node.physicsBody?.contactTestBitMask = Bitmasks.notInfected
        scoreView.peopleInfected += 1
    }
    
    public override func update(_ currentTime: TimeInterval) {
        if !gameHasEnded {
            // Slowly move all the computers down and remove them from going off-screen
            if let computers = self.children.filter({ $0.name == "computer" }) as? [SKSpriteNode] {
                computers.forEach { (computer) in
                    if computer.position.y < -computer.size.height || computer.position.x > self.size.width || computer.position.x < computer.size.width / 2 {
                        computer.removeFromParent()
                    } else {
                        computer.position.y -= 1
                    }
                }
            }
            // Prevent the player from going off-screen
            if let player = player {
                if player.position.x < player.size.width / 2 {
                    player.position.x = player.size.width / 2
                } else if player.position.x > self.size.width - player.size.width / 2 {
                    player.position.x = self.size.width - player.size.width / 2
                }
            }
        }
    }
}
