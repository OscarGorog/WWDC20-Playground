import SpriteKit
import Foundation

/// A `SKSpriteNode` subclass that creates a  `Tree` node
public class Tree: SKSpriteNode {
    init(texture: SKTexture) {
        super.init(texture: texture, color: .clear, size: texture.size())
        setupNode()
    }
    
    private func setupNode() {
        name = "tree"
        
        setupPhysicsBody()
    }
    
    private func setupPhysicsBody() {
        guard let texture = self.texture else { return }
        physicsBody = SKPhysicsBody(texture: texture, size: texture.size())
        physicsBody?.isDynamic = true
        physicsBody?.categoryBitMask = Bitmasks.tree
        physicsBody?.contactTestBitMask = Bitmasks.player
        physicsBody?.collisionBitMask = 0
        physicsBody?.usesPreciseCollisionDetection = true
        
        createTreeChild()
    }
    
    private func createTreeChild() {
        guard let texture = self.texture else { return }
        let computerAutoMoveNodeTree = SKShapeNode(rectOf: texture.size())
        computerAutoMoveNodeTree.physicsBody = SKPhysicsBody(texture: texture, size: texture.size())
        computerAutoMoveNodeTree.physicsBody?.isDynamic = true
        computerAutoMoveNodeTree.physicsBody?.categoryBitMask = Bitmasks.tree
        computerAutoMoveNodeTree.physicsBody?.contactTestBitMask = Bitmasks.computerLeftBorder | Bitmasks.computerRightBorder | Bitmasks.computerLeftBottomBorder
        computerAutoMoveNodeTree.physicsBody?.collisionBitMask = 0
        
        self.addChild(computerAutoMoveNodeTree)
    }
    
    required init(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}



