import UIKit
import Foundation

/// A subclass of  `CustomAlertView` that is pre-set up to present win alert
public class WinAlert: CustomAlertView {
    private var skovidGameViewController: SkovidGameViewController!
    private var gameScene: GameScene!
    
    public init(titleText: String, titleLabelFontSize: CGFloat, skovidGameViewController: SkovidGameViewController, gameScene: GameScene) {
        super.init(frame: .zero, titleText: titleText, titleLabelFontSize: titleLabelFontSize)
        self.skovidGameViewController = skovidGameViewController
        self.gameScene = gameScene
        
        setupView()
    }
    
    private func setupView() {
        alpha = 0
        
        addActions()
    }
    
    private func addActions() {
        // Add actions to the alert
        self.addAction(CustomAlertAction(buttonText: "Play Again", completionHandler: {
            UIView.animate(withDuration: 0.75, delay: 0, options: .curveEaseOut, animations: {
                self.alpha = 0
            }, completion: { (_) in
                self.removeFromSuperview()
                self.gameScene.restartGame()
            })
        }))
        self.addAction(CustomAlertAction(buttonText: "Main Menu", completionHandler: {
            let menuView = MenuView(gameScene: self.gameScene)
            self.skovidGameViewController.view.addSubview(menuView)
            
            // menuView constraints
            NSLayoutConstraint.activate([
                menuView.centerXAnchor.constraint(equalTo: self.skovidGameViewController.view.centerXAnchor, constant: 0),
                menuView.centerYAnchor.constraint(equalTo: self.skovidGameViewController.view.centerYAnchor, constant: 0),
                menuView.heightAnchor.constraint(equalToConstant: 175),
                menuView.widthAnchor.constraint(equalToConstant: 300)
            ])
            
            self.gameScene.restartGame(withPlayer: false)
            UIView.animate(withDuration: 0.75, delay: 0, options: .curveEaseOut, animations: {
                self.alpha = 0
                menuView.alpha = 1
            }, completion: { (_) in
                self.removeFromSuperview()
            })
        }))
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

